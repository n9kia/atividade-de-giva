Position2D = tuple[float, float]
Vector2D = tuple[float, float]
Position3D = tuple[float, float, float]
Vector2D = tuple[float, float, float]

# A 2D rectangle
# values are: [left, top, right botton]
# or: [x0,y0,x1,y1]
Rectangle2D = tuple[float,float,float,float]

#custom type for RGBA Color
Color = tuple[int, int, int, int]

def move2D(position: Position2D, speed: Vector2D):
    x = position[0] + speed[0]
    y = position[1] + speed[1]
    return (x,y)
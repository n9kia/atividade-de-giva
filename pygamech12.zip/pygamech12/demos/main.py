import pygame
from colors import *

pygame.init()

screen = pygame.display.set_mode((640, 240))

# while True:
#     for event in pygame.event.get():
#         print(event)

# pygame.quit()

screen.fill(YELLOW)
pygame.display.update()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()
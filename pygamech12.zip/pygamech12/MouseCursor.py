import pygame
import GameObject

class MouseCursor(GameObject.GameObject):
    def __init__(self):
        super().__init__()
        self.texture = pygame.image.load("images/mouse2.png")

    def update(self):
        mousePosition = pygame.mouse.get_pos()
        self.moveTo(mousePosition)
        return

    def draw(self,screen):
        pygame.mouse.set_visible(False)
        super().draw(screen)
        return
class Camera:
    def __init__(self,x,y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.heigth = height

    def move(self, dx, dy):
        self.x += dx
        self.y += dy
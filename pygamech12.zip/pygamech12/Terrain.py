import pygame
import Config

GRASS = 0
DIRT = 1
STONE = 2
COBBLESTONE = 3

def __loadTerrainTexture__(filename):
    texture = pygame.image.load(filename)
    size = (Config.TILE_SIZE, Config.TILE_SIZE)
    texture = pygame.transform.scale(texture, size)
    return texture

texture = [
__loadTerrainTexture__("images/grass.png"),
__loadTerrainTexture__("images/dirt.png"),
__loadTerrainTexture__("images/stone.png"),
__loadTerrainTexture__("images/cobblestone.png")
]